﻿import React, { Component } from 'react';

class ErrorBoundary extends Component {
    state = {
        hasError : false,
        ErrorMsg : ''
    }

    componentDidCatch = (error, info) => {
        this.setState({ hasError: 'true', ErrorMsg: error });
    }

    render() {
        if (this.state.hasError)
            return <tr><td>something is wrong</td></tr>;
        else
            return this.props.children;
    }
}

export default ErrorBoundary;


