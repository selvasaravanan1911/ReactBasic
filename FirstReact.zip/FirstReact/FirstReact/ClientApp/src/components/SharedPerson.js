﻿import * as React from 'react';
import { connect } from 'react-redux';

const SharedPerson = (props) => {
    return (
        <React.Fragment>

            <tr>
                <td>{props.name}</td>
                <td>{props.age}</td>
                <td><input type="button" value="Remove" onClick={props.click} /></td>
                <td><input type="text" onBlur={props.addclick} /></td>
            </tr>

         </React.Fragment>
        );
};

export default connect()(SharedPerson);
