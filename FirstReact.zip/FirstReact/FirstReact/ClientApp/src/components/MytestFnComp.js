﻿import React, { useState } from 'react';
import { connect } from 'react-redux';
import SharedPerson from './SharedPerson.js';

import ErrorBoundary from '../ErrorHandler/ErrorBoundary';

const MytestFnComp = props => {
    //person state
    const [personState, setPersonState] = useState({
        persons: [
            { Id: 101, name: 'John', age: 35 },
            { Id: 102, name: 'Karthik', age: 36 },
            { Id: 103, name: 'Geroge', age: 38 }
        ],
        showpersons: true
    });

    const [otherState, setOtherState] = useState({
        //persondept state
        personDepts: [
            { Dept: 'IT' },
            { Dept: 'IT' },
            { Dept: 'IT' }
        ]
    });

    //change state value on click event

    const MyclickHandler = () => {
        setPersonState({
            persons: [
                { Id: 101, name: 'Saravanan', age: 39 },
                { Id: 102, name: 'Karthik', age: 36 },
                { Id: 103, name: 'Geroge', age: 38 }
            ]
        });
        setOtherState({
            personDepts: [
                { Dept: 'Doc' },
                { Dept: 'Teacher' },
                { Dept: 'IT' }
            ]
        });
    }

    //show/Hide the state data on click event
    const MyclickToggle = () => {
        const Doeshow = personState.showpersons;
        setPersonState({
            showpersons: !Doeshow,
            persons: [
                { Id: 101, name: 'John', age: 35 },
                { Id: 102, name: 'Karthik', age: 36 },
                { Id: 103, name: 'Geroge', age: 38 }
            ]
        });
    }
    //delete row one by one based on index
    const deleteHandler = (index) => {
        const Doeshow = personState.showpersons;
        const tempstate = personState.persons;
        tempstate.splice(index, 1);
        setPersonState({ persons: tempstate, showpersons: Doeshow})
        
    }
    //add values to state
    const addHandler = (event, id) => {
        //check given ID is available in he state object
        let a = 10;
        let b = 10 / 0;
        const personindex = personState.persons.findIndex(p => {
            return p.Id === id;
        });
        //get specific row based on index
        const getperson = { ...personState.persons[personindex] };
        //assign given name
        getperson.name = event.target.value;
        //copy the object
        const personscopy = [...personState.persons];

        personscopy[personindex] = getperson;

        const boolPerson = personState.showpersons;
        //const personscopy = [...personState.persons];
        //tempstate.push({ name: event.target.value, age: '21'  });
        setPersonState({ persons: personscopy, showpersons: boolPerson })

    }

    let showhide = null;
    if (personState.showpersons) {
        showhide = (<div> <table>
            <thead>
                <td>Firstname</td>
                <td>Age</td>
            </thead>
            <tbody>
            {
                personState.persons.map((person, idx) => {
                    return <ErrorBoundary key={person.Id}>
                        <SharedPerson
                                click={() => deleteHandler(idx)}
                            name={person.name}
                                age={person.age}
                                addclick={(event) => addHandler(event, person.Id)} 
                                />
                            </ErrorBoundary>
                            
            })
                }
            </tbody>
        </table></div>);
    }
        
    return (
        <React.Fragment>
            <button onClick={MyclickToggle}>Toggle</button>

            <button onClick={MyclickHandler}>Click me</button>
            <h1>My Name: {personState.persons[0].name} and Age: {personState.persons[0].age}</h1>

            <h3>{props.children}</h3>
            <p onClick={props.myclick}>Click Reference</p>

                    <input id="name1" type="text" onChange={props.mychange} />
                    <input id="name2" type="text" onChange={props.mychange} />
                    <input id="name3" type="text" onChange={props.mychange} />
                    <p onClick={props.myclickfun}>Click Bind</p>
            {showhide}
        </React.Fragment>
    );
};



export default connect()(MytestFnComp);
