﻿import * as React from 'react';
import { connect } from 'react-redux';
//import { RouteComponentProps } from 'react-router';
import { Component } from 'react';
import PropTypes from 'prop-types';
import MytFnComp from './MytestFnComp.js';

//type TestclsProps =
//RouteComponentProps<{}>;

/*const Testcls = () => (
    <div>
        <h1>My test Page</h1>
    </div>
);*/



/*class Mytest extends React.PureComponent<TestclsProps> {
    public render() {
        return (
            <React.Fragment>
                <h1>My test Page</h1>
            </React.Fragment>
        );
    }
};*/


const propTypes = {
    name: PropTypes.string,
    age: PropTypes.number
};

class Mytest extends Component { 
    constructor(props) {
        super(props);
        this.state = {
            persons: [
                { name: 'John', age: 35 },
                { name: 'Karthik', age: 36 },
                {name: 'Geroge', age: 38 }
            ]
        }
    }
    

    MyclickHandler = (testName) => {
       // alert(testName);
        this.setState({
            persons: [
                { name: testName, age: 39 },
                { name: 'Karthik', age: 36 },
                { name: 'Geroge', age: 38 }
            ]
        });
    }
    MyChangeHandler = (event) => {
        if (event.target.id === "name1")
            var name1 = event.target.value
        if (event.target.id === "name2")
            var name2 = event.target.value
        if (event.target.id === "name3")
            var name3 = event.target.value
        this.setState({
            persons: [
                { name: name1, age: 39 },
                { name: name2, age: 36 },
                { name: name3, age: 38 }
            ]
        });
    }
    render() {
        return (
            <React.Fragment>
                <h1>My Name using props: {this.props.name} and Age: {this.props.age}</h1>
                <button onClick={this.MyclickHandler}>Click me</button>
                <h2>My name from state: {this.state.persons[0].name}</h2>
                <h2>My name from state: {this.state.persons[1].name} and {this.state.persons[1].age}</h2>
                <h2>My name from state: {this.state.persons[2].name} and {this.state.persons[2].age}</h2>
                <h3>{this.props.children}</h3>

                <MytFnComp mychange={this.MyChangeHandler} myclickfun={this.MyclickHandler.bind(this, 'test')} />
            </React.Fragment>
        );
    }
};

Mytest.propTypes = propTypes;

export default connect()(Mytest);